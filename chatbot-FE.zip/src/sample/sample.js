export const sample = 


{
    "messages":["message1","msg2","msg3"],  //[msg1,msg2]
    "charts":[
]
    
}

//------------------------------><-------------------------------//
export const sample2 = {
  "messages":["msg1","msg1","msg3"],
  "id":21,
  "charts":[
    {
      "columns":["a","b"],
      "data":[
        ['bhargava ',10],
        ['arpit',15],
        ['abc',20],
        ['sree',25],
        ['mnc',28],
        ['mnc1',28],
      ],

      "enable_chart":true,

    },
    {
      "columns":["name","count","ch"],
      "data":[
        ['emp1',10,6],
        ['emp2',15,7],
        ['asbc',20,8],
        ['ssree',25,9],
        ['mssnc',28,10],
        ['mnssc1',28,10],
        ['mnssc2',28,10],
        ['mnssc3',28,10],
        ['mnssc22',28,10],
        ['mnssc12',28,10],
        ['mnssc1q',28,10],
        ['mnssc1t',28,10],
        ['mnssc1wrwer',28,10],
        ['mnssc1ww',28,10],
        ['mnssc1q',28,10],
        ['mnssc1543',28,10],
        ['mnssc1hjh',28,10],
        ['mnssc1ds',28,10],
        ['mnssc1dfag',28,10],
        ['mnssc1t43',28,10],
        ['mnssc16yt',28,10],
        ['mnssc1y',28,10],
        ['mnssc1u',28,10],
        ['mnssc1i',28,10],
        ['mnssc1o',28,10],
        ['mnssc1l',28,10],
        ['mnssc1io',28,10],
        ['mnssc1yy',28,10],
        ['mnssc1z',28,10],
        ['mnssc1x',28,10],
        ['mnssc1c',28,10],
        ['mnssc1v',28,10],
        ['mnssc1b',28,10],
        ['mnssc1bb',28,10],
        ['mnssc1n',28,10],
        ['mnssc1v',28,10],
        ['mnssc1vv',28,10],
        ['mnssc1n',28,10],
        ['mnssc1nm',28,10],
        ['mnssc1nn',28,10],
        ['mnssc1ggf',28,10],
        ['mnssc1aa',28,10],
        ['mnssc1sff',28,10],

     


      ],

      "enable_chart":true,

    },
    {
      "columns":["name"],
      "data":[
        ['bhargava'],
        ['arpit'],
        ['abc'],
        ['sree'],
        ['mnc'],
        ['mnc1'],
      ],

      "enable_chart":true,

    }
  ]
}






