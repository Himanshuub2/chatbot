
import SendIcon from "@mui/icons-material/Send";
import { useDispatch } from "react-redux";
import { chatDetails, loading, userQuestion } from "../../redux/chatSlice";
import "../../index.css";
import { useState } from "react";



const ChatFooter = ({sendMessage}) => {
  const dispatch = useDispatch();



  const [question, setQuestion] = useState("");

  const handleSubmit = async () => {
    sendMessage(question)
    // webSocket.send(question);
    dispatch(userQuestion(question));
    dispatch(loading(true));
    setQuestion("");
  };

  return (
    <div className="flex justify-evenly items-center w-full h-1/2  ">
      <input
        id="input-field"
        value={question}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            handleSubmit();
          }
        }}
        onChange={(e) => setQuestion(e.target.value)}
        className="w-[80%] h-[100%] border-1 rounded-[3rem] bg-darkBlue"
        placeholder="Transform Questions into Insights !"
      ></input>

      <button
        onClick={handleSubmit} style={{textAlign:"center"}}
        className="bg-cyanBlue w-[12%] h-[90%] rounded-[9999px] pl-[6px]"
      >
        <SendIcon sx={{ color: "white",width:"50%" }} />
      </button>
    </div>
  );
};

export default ChatFooter;
